Unzip everything in a single folder. Open home.html first and then navigate using the directions.

Arizona_County_Election_Map.R is the solution for bonus assignment for displaying election results using map shape data in R. Please change the path to the shape file in the R file appropriately.

tennis_color_by_victory_bonus.html is the solution to the bonus question for displaying tennis data based on victory.